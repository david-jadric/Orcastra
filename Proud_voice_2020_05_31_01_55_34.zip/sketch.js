//examples of a main functin to run in p5.js

var sequence = 'cggctctttgttagccgaatgagcgattcctgaagtctgggcgtttgaccctcataagggtttcttccaatattggagttcacacttgcgtgagacaccaattcaacgatcttgaatccccatcgaggtgcataaaggacacgcgaagtaaaaatgagtaatggtgacccatagggctactaatagttcaacttcaacgcataccatatgttgtaggaatcgtgatagcgtccgctgtctcaccgagaattaccgagctatcaccaacgtcaaacgctaaaacatcccttagcgtatgaaatttatcggcgtagcttcggaatctcttgcgtaagacatcattcacgagcggacaaagattagaccaattgcccggttatctattagaaatactagcgcaactgccgcctgcgtgggccccgcccgcaaccgtgaccctgcgaagaatacgtgatccatggaagtccttccttccactaaagtgttagggttcatgaccccggtcatgcagtgaatttgtaatattcggagtggactcaatgtagtctatgcagaaaagagcgtacactcgctgactaatagccgggctccagtcccccaattggttatcaccagttccatgggctggccgcagagtctcttatatatgtttaaaacgtgccggttctgccaaaacttaagtaggttcctgtgtattattgaatccactaccgcactctgcggtttcagactggtcaactctagctgtccacggcatagtagtacgcacgaagtggcgtagttgcgagcaatgtcgactgcatagttgcatgcgtagagcggtggtctgcataaaagcatctcagcatacaaccaaagtgggtgtgtgctttagtgtagtccacggttagtaaggggtagagaatgtggtgaaccatggggaccgctctattcgcataatgtaaactcagagtactggggagtcacaagtctccagagtagattaaagtaaggcagagtc'

var i = 2;





function ribosome(sequence){
//this function takes a dna sequence and turns it into a codon for creation of an aminoAcid
  codon = sequence[i-2] +sequence[i-1] + sequence[i];
  i +=3 ;
  return codon
}

function setup() {
  //class aminoAcids lives here with 

class aminoAcid {
  constructor(codon) {
    this.codon = codon
     this.xPos = random(0, 600);
     this.yPos = random(0, 600);
  }
  sugarColor = {
    'a':0,
    't':85,
    'g':170,
    'c':255
  };

   aminoAcids() {
     fill(this.sugarColor[codon[0]], 
      this.sugarColor[codon[1]],
      this.sugarColor[codon[2]]);
     rectMode(CENTER);
     rect(this.xPos, this.yPos,100,100)
   }
}
aa = new aminoAcid(ribosome(sequence));



  createCanvas(600, 600);
  setInterval(function() {
  ribosome(sequence)
  aa = new aminoAcid(ribosome(sequence));
  console.log(aa.codon)
  
}, 1000);
  }


function draw() {
  background(0);
  aa.aminoAcids()

}